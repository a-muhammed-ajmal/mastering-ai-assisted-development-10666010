import React from 'react';
import { CursorProvider } from './contexts/CursorContext';
import NoiseBackground from './components/NoiseBackground';
import CustomCursor from './components/CustomCursor';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Work from './components/Work';
import Philosophy from './components/Philosophy';
import Services from './components/Services';
import Footer from './components/Footer';
import Marquee from './components/Marquee';

function App() {
  return (
    <CursorProvider>
      <main className="relative w-full min-h-screen bg-offwhite text-jetblack overflow-hidden selection:bg-coral selection:text-white">
        <NoiseBackground />
        <CustomCursor />
        
        <Navbar />
        
        {/* Content Stack */}
        <div className="relative z-10 flex flex-col">
          <Hero />
          <Work />
          <Philosophy />
          <Services />
          <Footer />
        </div>

        <Marquee />
      </main>
    </CursorProvider>
  );
}

export default App;