import React from 'react';
import { motion } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const Philosophy: React.FC = () => {
  const { setCursorType } = useCursor();

  return (
    <section className="relative w-full py-32 md:py-48 px-6 md:px-16 bg-jetblack text-offwhite z-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row gap-12 md:gap-24">
          
          {/* Label */}
          <div className="md:w-1/4">
            <span className="block font-satoshi font-medium text-xs uppercase tracking-[0.3em] text-coral mb-4">
              (Philosophy)
            </span>
            <div className="h-[1px] w-12 bg-offwhite/30" />
          </div>

          {/* Main Text */}
          <div className="md:w-3/4">
            <motion.h2 
              className="font-clash font-medium text-4xl md:text-6xl lg:text-[80px] leading-[1.1] tracking-tight mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              We believe safe design is <span className="text-coral italic">risky business</span>. In a world of infinite noise, blending in is the fastest way to die.
            </motion.h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 text-offwhite/60 font-satoshi text-lg leading-relaxed">
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2, duration: 0.8 }}
              >
                HAUS is not for everyone. We build for the bold, the disruptors, and the outliers. We strip away the unnecessary to reveal the raw truth of your brand.
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4, duration: 0.8 }}
              >
                Our process is chaotic by design. We break things to put them back together in ways that haven't been seen before. Art direction meets strategic precision.
              </motion.p>
            </div>
            
            <div className="mt-16">
                 <span 
                    className="font-clash font-bold text-9xl text-jetblack text-stroke-white opacity-20 select-none pointer-events-none"
                    style={{ WebkitTextStroke: '1px #f2efe9' }}
                 >
                    NOISE
                 </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Philosophy;