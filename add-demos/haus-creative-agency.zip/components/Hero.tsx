import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const Hero: React.FC = () => {
  const { setCursorType } = useCursor();
  const [isBuryHovered, setIsBuryHovered] = useState(false);

  // Animation Variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.08,
        delayChildren: 0.2
      }
    }
  };

  const wordVariants = {
    hidden: { y: 40, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { type: "spring", stiffness: 100, damping: 20 }
    }
  };

  const lineVariants = {
    hidden: { width: 0, opacity: 0 },
    visible: { 
      width: 32, 
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut", delay: 0.5 }
    }
  };

  const imageVariants = {
    hidden: { scale: 1.1, opacity: 0 },
    visible: { 
      scale: 1.0, 
      opacity: 1,
      transition: { duration: 1.2, ease: "easeOut", delay: 0.4 }
    }
  };

  const headlineWords1 = ["WE", "DON'T", "FOLLOW"];
  const headlineWords2 = ["TRENDS.", "WE"];

  return (
    <section className="relative w-full min-h-screen pt-32 pb-20 px-6 md:px-16 flex flex-col md:flex-row z-10">
      
      {/* LEFT COLUMN */}
      <motion.div 
        className="w-full md:w-[55%] flex flex-col justify-center pt-8 md:pt-16"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        {/* Eyebrow */}
        <div className="flex items-center gap-4 mb-6 md:mb-8">
          <motion.div variants={lineVariants} className="h-[1.5px] bg-coral" />
          <motion.span 
            variants={wordVariants}
            className="font-satoshi font-medium text-[12px] uppercase tracking-[0.3em] text-jetblack/40"
          >
            Creative Studio — Est. 2020
          </motion.span>
        </div>

        {/* Headline */}
        <div className="font-clash font-bold text-5xl md:text-7xl lg:text-[96px] leading-[0.92] tracking-[-0.04em] text-jetblack max-w-2xl mb-8">
          <div className="flex flex-wrap gap-x-3 md:gap-x-6">
            {headlineWords1.map((word, i) => (
              <motion.span key={i} variants={wordVariants} className="inline-block">{word}</motion.span>
            ))}
          </div>
          <div className="flex flex-wrap gap-x-3 md:gap-x-6 mt-1 md:mt-4">
             {headlineWords2.map((word, i) => (
              <motion.span key={i} variants={wordVariants} className="inline-block">{word}</motion.span>
            ))}
             <motion.span 
              variants={wordVariants}
              className="inline-block text-coral cursor-pointer origin-center"
              animate={isBuryHovered ? { rotate: -3, scale: 1.05 } : { rotate: 0, scale: 1 }}
              onMouseEnter={() => { setIsBuryHovered(true); setCursorType('hover'); }}
              onMouseLeave={() => { setIsBuryHovered(false); setCursorType('default'); }}
              transition={{ type: "spring", stiffness: 300, damping: 15 }}
             >
               BURY
             </motion.span>
             <motion.span variants={wordVariants} className="inline-block text-coral">THEM.</motion.span>
          </div>
        </div>

        {/* Subtext */}
        <motion.p 
          variants={wordVariants}
          className="font-satoshi font-normal text-[17px] text-jetblack/60 leading-relaxed max-w-md mt-4 md:mt-8"
        >
          Brand strategy, digital design, and motion for companies that refuse to blend in.
        </motion.p>

        {/* CTA */}
        <motion.div variants={wordVariants} className="mt-10 md:mt-12 group inline-block w-max cursor-pointer">
          <div 
            className="flex items-center gap-2"
            onMouseEnter={() => setCursorType('hover')}
            onMouseLeave={() => setCursorType('default')}
          >
            <span className="font-satoshi font-bold text-[14px] uppercase tracking-[0.15em] text-jetblack">
              See Our Work
            </span>
            <span className="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 text-coral">
              →
            </span>
          </div>
          <div className="h-[2px] bg-coral w-0 group-hover:w-full transition-all duration-300 mt-1" />
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div 
          variants={wordVariants}
          className="hidden md:flex items-center gap-4 mt-24"
        >
          <div className="h-16 w-[1px] bg-jetblack/20 relative overflow-hidden">
            <motion.div 
              className="absolute top-0 left-[-1px] w-[3px] h-[6px] bg-jetblack rounded-full"
              animate={{ y: [0, 60] }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            />
          </div>
          <span className="font-satoshi font-normal text-[11px] text-jetblack/30 tracking-widest -rotate-90 origin-left translate-y-3 translate-x-2">
            SCROLL
          </span>
        </motion.div>
      </motion.div>

      {/* RIGHT COLUMN - IMAGE */}
      <motion.div 
        className="hidden md:block absolute right-0 top-0 bottom-0 w-[45%] h-full pointer-events-none"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <div className="relative w-full h-full flex items-center justify-center pr-16">
          <motion.div 
            variants={imageVariants}
            className="relative w-full h-[80vh] overflow-hidden pointer-events-auto group"
            style={{ 
              clipPath: 'polygon(15% 0, 100% 0, 100% 100%, 0 85%)'
            }}
            onMouseEnter={() => setCursorType('hover')}
            onMouseLeave={() => setCursorType('default')}
          >
            <img 
              src="https://picsum.photos/800/1200?grayscale" 
              alt="Architecture" 
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-in-out scale-100 group-hover:scale-105"
            />
            
            {/* Rotating Ring Overlay */}
            <div className="absolute -bottom-16 -left-16 w-64 h-64 z-20 pointer-events-none mix-blend-difference">
               <svg className="w-full h-full animate-spin-slow" viewBox="0 0 100 100">
                <path
                  id="circlePath"
                  d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"
                  fill="transparent"
                />
                <text className="fill-white font-satoshi font-bold text-[11px] uppercase tracking-[0.2em]">
                  <textPath href="#circlePath" startOffset="0%">
                    Haus · Creative · Studio · Haus · Creative · Studio ·
                  </textPath>
                </text>
              </svg>
            </div>
          </motion.div>
        </div>
      </motion.div>

    </section>
  );
};

export default Hero;