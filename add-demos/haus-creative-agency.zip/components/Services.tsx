import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const services = [
  { id: '01', title: 'Brand Identity', desc: 'Visual Systems, Logo Design, Guidelines' },
  { id: '02', title: 'Digital Design', desc: 'Websites, Apps, Interactive Experiences' },
  { id: '03', title: 'Art Direction', desc: 'Photography, Video, Set Design' },
  { id: '04', title: 'Motion', desc: '2D/3D Animation, Micro-interactions' },
  { id: '05', title: 'Strategy', desc: 'Positioning, Voice, Market Research' },
];

const Services: React.FC = () => {
  const { setCursorType } = useCursor();
  const [activeService, setActiveService] = useState<number | null>(null);

  return (
    <section className="relative w-full py-32 px-6 md:px-16 bg-offwhite text-jetblack z-20">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row">
        
        {/* Title */}
        <div className="md:w-1/3 mb-16 md:mb-0">
          <h2 className="font-clash font-bold text-5xl md:text-7xl uppercase leading-none sticky top-32">
            Our<br/>Services
          </h2>
        </div>

        {/* List */}
        <div className="md:w-2/3">
          {services.map((service, index) => (
            <div 
              key={service.id}
              className="group border-t border-jetblack/20 last:border-b py-12 transition-all duration-300 hover:bg-white hover:px-8 -mx-8 px-8 md:px-8 md:hover:px-12"
              onMouseEnter={() => {
                setActiveService(index);
                setCursorType('hover');
              }}
              onMouseLeave={() => {
                setActiveService(null);
                setCursorType('default');
              }}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-baseline gap-6">
                  <span className="font-satoshi text-xs uppercase tracking-widest text-coral">
                    {service.id}
                  </span>
                  <h3 className="font-clash font-semibold text-3xl md:text-5xl uppercase group-hover:text-coral transition-colors duration-300">
                    {service.title}
                  </h3>
                </div>
                
                <div className="overflow-hidden md:text-right">
                  <motion.p 
                    className="font-satoshi text-jetblack/60 text-sm md:text-base"
                    initial={{ opacity: 0.5 }}
                    animate={{ opacity: activeService === index ? 1 : 0.5 }}
                  >
                    {service.desc}
                  </motion.p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;