import React, { useEffect, useState } from 'react';
import { motion, useSpring, useMotionValue } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const CustomCursor: React.FC = () => {
  const { cursorType } = useCursor();
  const [isMobile, setIsMobile] = useState(false);
  
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);
  
  const springConfig = { damping: 25, stiffness: 300 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.matchMedia('(max-width: 768px)').matches);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
    };

    window.addEventListener('mousemove', moveCursor);
    return () => {
      window.removeEventListener('resize', checkMobile);
      window.removeEventListener('mousemove', moveCursor);
    };
  }, [cursorX, cursorY]);

  if (isMobile) return null;

  const variants = {
    default: {
      width: 12,
      height: 12,
      backgroundColor: '#ff4d3a',
      opacity: 1,
      mixBlendMode: 'normal' as const,
      filter: 'blur(0px)',
    },
    hover: {
      width: 48,
      height: 48,
      backgroundColor: 'transparent',
      border: '2px solid #ff4d3a',
      opacity: 0.8,
      mixBlendMode: 'difference' as const, // Cool effect over text
      filter: 'blur(2px)',
    }
  };

  return (
    <motion.div
      className="fixed left-0 top-0 pointer-events-none z-[100] rounded-full anchor-center"
      style={{
        translateX: cursorXSpring,
        translateY: cursorYSpring,
        x: '-50%',
        y: '-50%',
      }}
      variants={variants}
      animate={cursorType}
      transition={{ type: 'spring', stiffness: 500, damping: 28 }}
    />
  );
};

export default CustomCursor;