import React from 'react';

const Marquee: React.FC = () => {
  return (
    <div className="fixed bottom-0 left-0 w-full py-4 overflow-hidden z-10 pointer-events-none mix-blend-multiply">
      <div className="relative w-full flex whitespace-nowrap">
        <div className="animate-marquee flex gap-8 pr-8">
          {[...Array(4)].map((_, i) => (
            <span key={i} className="font-clash font-semibold text-[32px] md:text-[48px] text-jetblack/10 uppercase">
              Branding — Digital — Motion — Strategy —
            </span>
          ))}
        </div>
        <div className="absolute top-0 animate-marquee2 flex gap-8 pr-8" aria-hidden="true">
          {[...Array(4)].map((_, i) => (
            <span key={i} className="font-clash font-semibold text-[32px] md:text-[48px] text-jetblack/10 uppercase">
              Branding — Digital — Motion — Strategy —
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Marquee;