import React from 'react';
import { motion } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const Footer: React.FC = () => {
  const { setCursorType } = useCursor();

  return (
    <footer className="relative w-full bg-jetblack text-offwhite pt-32 pb-12 px-6 md:px-16 z-20 overflow-hidden">
      
      {/* Top Section */}
      <div className="flex flex-col md:flex-row justify-between items-start mb-32">
        <div className="mb-12 md:mb-0">
          <span className="font-satoshi font-medium text-xs uppercase tracking-[0.3em] text-coral">
            (Contact)
          </span>
          <h3 className="font-clash font-medium text-4xl mt-6 max-w-sm leading-tight">
            Have an idea? Let's build something dangerous.
          </h3>
        </div>
        
        <div className="flex flex-col gap-6 text-right">
            {['Instagram', 'Twitter', 'LinkedIn', 'Behance'].map((social) => (
                <a 
                    key={social}
                    href="#" 
                    className="font-satoshi text-sm uppercase tracking-widest hover:text-coral transition-colors"
                    onMouseEnter={() => setCursorType('hover')}
                    onMouseLeave={() => setCursorType('default')}
                >
                    {social}
                </a>
            ))}
        </div>
      </div>

      {/* Massive Email Link */}
      <div className="w-full border-t border-offwhite/10 pt-16 mb-24">
        <a 
            href="mailto:hello@haus.agency"
            className="block w-full font-clash font-bold text-[10vw] md:text-[13vw] leading-[0.8] text-center uppercase text-offwhite hover:text-coral transition-colors duration-500 break-all"
            onMouseEnter={() => setCursorType('hover')}
            onMouseLeave={() => setCursorType('default')}
        >
            HELLO@HAUS
        </a>
      </div>

      {/* Bottom info */}
      <div className="flex flex-col md:flex-row justify-between items-end text-xs font-satoshi text-offwhite/40 uppercase tracking-widest">
        <div className="flex flex-col gap-2 mb-8 md:mb-0">
            <span>Berlin — 10115</span>
            <span>Torstraße 123</span>
        </div>
        <div className="flex gap-8">
            <span>© 2024 HAUS Agency</span>
            <span>Privacy Policy</span>
            <span>Imprint</span>
        </div>
      </div>

      {/* Noise overlay specific to footer for consistency if main bg scrolls away */}
      <div className="absolute inset-0 bg-white opacity-[0.02] pointer-events-none mix-blend-overlay" />
    </footer>
  );
};

export default Footer;