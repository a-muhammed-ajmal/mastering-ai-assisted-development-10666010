import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const projects = [
  { 
    id: '01', 
    client: 'AEON', 
    title: 'Digital Renaissance', 
    category: 'Web Experience', 
    year: '2024',
    img: 'https://picsum.photos/id/237/1200/800',
    align: 'justify-start'
  },
  { 
    id: '02', 
    client: 'VOLT', 
    title: 'Electric Dreams', 
    category: 'Rebranding', 
    year: '2023',
    img: 'https://picsum.photos/id/13/1000/1200',
    align: 'justify-end'
  },
  { 
    id: '03', 
    client: 'OASIS', 
    title: 'Future Habitat', 
    category: 'Art Direction', 
    year: '2023',
    img: 'https://picsum.photos/id/28/1400/900',
    align: 'justify-center'
  },
];

const Work: React.FC = () => {
  const { setCursorType } = useCursor();
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);

  return (
    <section className="relative w-full py-32 px-6 md:px-16 bg-offwhite text-jetblack z-20">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-24 border-b border-jetblack pb-6">
        <h2 className="font-clash font-bold text-6xl md:text-8xl leading-none uppercase">
          Selected<br/>Works
        </h2>
        <span className="font-satoshi font-medium text-sm md:text-base uppercase tracking-widest mt-4 md:mt-0">
          (2023 — 2024)
        </span>
      </div>

      {/* Projects List */}
      <div className="flex flex-col gap-32 md:gap-48">
        {projects.map((project) => (
          <div key={project.id} className={`flex w-full ${project.align}`}>
            <motion.div 
              className="relative w-full md:w-[70%] group cursor-none"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-10%" }}
              transition={{ duration: 0.8 }}
              onMouseEnter={() => {
                setCursorType('hover');
                setHoveredProject(project.id);
              }}
              onMouseLeave={() => {
                setCursorType('default');
                setHoveredProject(null);
              }}
            >
              {/* Image Container */}
              <div className="overflow-hidden relative">
                <motion.img 
                  src={`${project.img}?grayscale`} 
                  alt={project.title}
                  className="w-full h-auto object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-100 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-coral/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 mix-blend-multiply pointer-events-none" />
              </div>

              {/* Project Info - Overlay or Below */}
              <div className="flex justify-between items-start mt-4 border-t border-jetblack/20 pt-4">
                <div className="flex flex-col">
                  <span className="font-satoshi font-bold text-xs uppercase tracking-[0.2em] text-coral mb-2">
                    {project.id} — {project.category}
                  </span>
                  <h3 className="font-clash font-semibold text-3xl md:text-5xl uppercase group-hover:translate-x-4 transition-transform duration-500">
                    {project.client}
                  </h3>
                </div>
                <div className="text-right">
                  <span className="font-satoshi text-sm uppercase tracking-widest text-jetblack/50 block">
                    {project.year}
                  </span>
                  <span className="font-clash text-lg md:text-xl mt-1 block">
                    {project.title}
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        ))}
      </div>

      {/* View All Button */}
      <div className="w-full flex justify-center mt-32">
        <button 
          className="group relative px-8 py-4 overflow-hidden border border-jetblack rounded-full hover:bg-jetblack transition-colors duration-300"
          onMouseEnter={() => setCursorType('hover')}
          onMouseLeave={() => setCursorType('default')}
        >
          <span className="relative z-10 font-satoshi font-bold text-sm uppercase tracking-[0.2em] group-hover:text-offwhite transition-colors duration-300">
            View All Projects
          </span>
        </button>
      </div>
    </section>
  );
};

export default Work;