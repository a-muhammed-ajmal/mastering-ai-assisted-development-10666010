import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCursor } from '../contexts/CursorContext';

const Navbar: React.FC = () => {
  const { setCursorType } = useCursor();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const links = [
    { name: 'Work', href: '#' },
    { name: 'About', href: '#' },
    { name: 'Contact', href: '#' },
  ];

  const handleMouseEnter = () => setCursorType('hover');
  const handleMouseLeave = () => setCursorType('default');

  return (
    <>
      <nav className="fixed top-0 left-0 w-full z-50 px-6 md:px-16 py-6 flex justify-between items-center bg-transparent">
        {/* Logo */}
        <div 
          className="font-satoshi font-bold text-[18px] uppercase tracking-[0.2em] text-jetblack z-50 cursor-pointer"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          Haus®
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <div className="flex items-center gap-6">
            {links.map((link, i) => (
              <React.Fragment key={link.name}>
                <a 
                  href={link.href}
                  className="font-satoshi font-medium text-[13px] uppercase tracking-[0.15em] text-jetblack/50 hover:text-jetblack transition-colors duration-300"
                  onMouseEnter={handleMouseEnter}
                  onMouseLeave={handleMouseLeave}
                >
                  {link.name}
                </a>
                {i < links.length - 1 && <span className="text-jetblack/30">·</span>}
              </React.Fragment>
            ))}
          </div>

          <button 
            className="group relative w-10 h-10 rounded-full bg-coral flex items-center justify-center overflow-hidden transition-all duration-300 hover:scale-110"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <svg 
              width="16" 
              height="16" 
              viewBox="0 0 24 24" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className="text-white transform transition-transform duration-500 group-hover:rotate-45"
            >
              <path d="M7 17L17 7M17 7H7M17 7V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        {/* Mobile Hamburger */}
        <div 
          className="md:hidden z-50 cursor-pointer flex flex-col gap-[6px] w-[24px]"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <motion.span 
            animate={isMenuOpen ? { rotate: 45, y: 8 } : { rotate: 0, y: 0 }} 
            className="w-full h-[2px] bg-jetblack block origin-center"
          />
          <motion.span 
            animate={isMenuOpen ? { opacity: 0 } : { opacity: 1 }} 
            className="w-full h-[2px] bg-jetblack block"
          />
          <motion.span 
            animate={isMenuOpen ? { rotate: -45, y: -8 } : { rotate: 0, y: 0 }} 
            className="w-full h-[2px] bg-jetblack block origin-center"
          />
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: '-100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '-100%' }}
            transition={{ duration: 0.5, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 bg-offwhite z-40 flex flex-col justify-center px-6"
          >
            <div className="flex flex-col gap-4">
              {links.map((link, i) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + i * 0.1, duration: 0.5 }}
                  className="font-clash font-bold text-6xl text-jetblack hover:text-coral transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </motion.a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;